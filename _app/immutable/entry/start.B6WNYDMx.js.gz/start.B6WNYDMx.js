import{l as o,a as r}from"../chunks/BcPtsqA7.js";export{o as load_css,r as start};
