import{l as o,a as r}from"../chunks/BZ03YkHl.js";export{o as load_css,r as start};
