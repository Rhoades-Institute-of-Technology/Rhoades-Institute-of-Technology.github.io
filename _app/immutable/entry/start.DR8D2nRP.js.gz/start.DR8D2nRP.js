import{l as o,a as r}from"../chunks/gbrdgY9G.js";export{o as load_css,r as start};
