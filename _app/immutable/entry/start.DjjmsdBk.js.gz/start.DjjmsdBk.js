import{l as o,a as r}from"../chunks/SS9pgAeM.js";export{o as load_css,r as start};
