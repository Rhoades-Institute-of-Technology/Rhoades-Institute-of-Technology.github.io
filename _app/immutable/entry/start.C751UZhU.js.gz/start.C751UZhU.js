import{l as o,a as r}from"../chunks/BMdPrzVZ.js";export{o as load_css,r as start};
