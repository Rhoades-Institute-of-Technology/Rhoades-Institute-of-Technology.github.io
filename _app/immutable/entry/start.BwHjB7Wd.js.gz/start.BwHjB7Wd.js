import{l as o,a as r}from"../chunks/CqueH5Iv.js";export{o as load_css,r as start};
