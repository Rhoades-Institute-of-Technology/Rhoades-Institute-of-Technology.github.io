import{l as o,a as r}from"../chunks/Ra0V-M2_.js";export{o as load_css,r as start};
