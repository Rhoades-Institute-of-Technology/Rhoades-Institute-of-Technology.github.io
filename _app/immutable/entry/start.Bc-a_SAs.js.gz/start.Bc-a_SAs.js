import{l as o,a as r}from"../chunks/C22fOM8e.js";export{o as load_css,r as start};
