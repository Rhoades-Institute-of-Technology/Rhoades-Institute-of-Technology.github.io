import{l as o,a as r}from"../chunks/Uip4-hwl.js";export{o as load_css,r as start};
