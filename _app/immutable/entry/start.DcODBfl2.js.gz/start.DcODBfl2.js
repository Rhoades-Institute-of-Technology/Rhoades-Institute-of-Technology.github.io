import{l as o,a as r}from"../chunks/giFVfn-3.js";export{o as load_css,r as start};
