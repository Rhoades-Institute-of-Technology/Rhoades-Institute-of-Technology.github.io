import{l as o,a as r}from"../chunks/D4-TuDF9.js";export{o as load_css,r as start};
