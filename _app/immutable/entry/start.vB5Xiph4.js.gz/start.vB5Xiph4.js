import{l as o,a as r}from"../chunks/CQTk48Fl.js";export{o as load_css,r as start};
