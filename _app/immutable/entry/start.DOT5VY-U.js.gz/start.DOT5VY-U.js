import{l as o,a as r}from"../chunks/Dhq5oGHy.js";export{o as load_css,r as start};
