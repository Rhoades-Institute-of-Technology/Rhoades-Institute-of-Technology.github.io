import{l as o,a as r}from"../chunks/DiO1widH.js";export{o as load_css,r as start};
