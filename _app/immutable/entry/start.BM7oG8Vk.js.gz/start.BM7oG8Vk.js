import{l as o,a as r}from"../chunks/BoRGPJCk.js";export{o as load_css,r as start};
