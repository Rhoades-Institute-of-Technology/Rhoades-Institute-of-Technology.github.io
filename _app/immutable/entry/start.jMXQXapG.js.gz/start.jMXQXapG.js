import{l as o,a as r}from"../chunks/LAZn_Y6W.js";export{o as load_css,r as start};
