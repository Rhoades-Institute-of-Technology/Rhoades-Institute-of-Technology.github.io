import{l as o,a as r}from"../chunks/UBXm8txZ.js";export{o as load_css,r as start};
