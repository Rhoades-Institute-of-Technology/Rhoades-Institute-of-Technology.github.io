import{l as o,a as r}from"../chunks/BqZ4f6kL.js";export{o as load_css,r as start};
