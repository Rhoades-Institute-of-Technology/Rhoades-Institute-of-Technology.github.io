import{l as o,a as r}from"../chunks/DBcp1QTz.js";export{o as load_css,r as start};
