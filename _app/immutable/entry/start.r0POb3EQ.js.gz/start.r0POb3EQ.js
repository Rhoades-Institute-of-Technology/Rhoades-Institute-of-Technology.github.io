import{l as o,a as r}from"../chunks/jDTB0nTG.js";export{o as load_css,r as start};
