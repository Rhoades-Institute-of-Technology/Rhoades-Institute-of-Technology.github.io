import{l as o,a as r}from"../chunks/xb1DOLnp.js";export{o as load_css,r as start};
