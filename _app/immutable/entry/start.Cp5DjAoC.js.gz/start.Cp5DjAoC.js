import{l as o,a as r}from"../chunks/DJt8qHYQ.js";export{o as load_css,r as start};
