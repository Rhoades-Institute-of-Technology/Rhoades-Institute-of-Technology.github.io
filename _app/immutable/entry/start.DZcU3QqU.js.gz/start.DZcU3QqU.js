import{l as o,a as r}from"../chunks/CS3ksFSQ.js";export{o as load_css,r as start};
