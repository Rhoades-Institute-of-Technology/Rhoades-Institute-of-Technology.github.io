import{l as o,a as r}from"../chunks/Drc5qhLm.js";export{o as load_css,r as start};
